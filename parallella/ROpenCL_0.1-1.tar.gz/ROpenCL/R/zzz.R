
.onLoad <- function(libname, pkgname){
    loadRcppModules()
}

